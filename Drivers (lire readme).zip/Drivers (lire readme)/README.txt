� mettre dans C:\Qt\5.2.1\mingw48_32\plugins\sqldrivers

Si probl�mes, contactez moi. 
Pour la version finale, il faudra mettre dans le dossier o� se situe l'executable un dossier sqldrivers et y mettre tout ce qu'il y a ici.
De plus, il faudra mettre l� o� se trouve l'executable le fichier libpq.dll de PostgreSQL.